package handExp;

public class Example1 {
	public static void main(String args[]){
		try{
			System.out.println("Starting of try block");
			
			throw new expHand("My error Message");
		}
		catch(expHand exp){
			System.out.println("Catch Block") ;
			System.out.println(exp) ;
		}
	}
}


