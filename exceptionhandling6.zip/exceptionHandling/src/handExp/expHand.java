package handExp;

class expHand extends Exception {
	
		   
		String str1;
		   expHand(String str2) {
			str1=str2;
		   }
		   public String toString(){ 
			return ("Exception Occurred: "+str1) ;
		   }
		}
		



