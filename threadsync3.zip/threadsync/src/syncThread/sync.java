package syncThread;


class sync {
	public void send(String msg) 
    { 
        System.out.println("Sending\t"  + msg ); 
        try
        { 
            Thread.sleep(1000); 
        } 
        catch (Exception e) 
        { 
            System.out.println("Thread  interrupted."); 
        } 
        System.out.println("\n" + msg + "Sent"); 
    } 
} 
class ThreadedSend extends Thread 
{ 
    private String msg; 
     
    sync  sync; 
    ThreadedSend(String m,  sync obj) 
    { 
        msg = m; 
        sync = obj; 
    } 
  
    public void run() 
    {  
        synchronized(sync) 
        { 
            sync.send(msg); 
        } 
    } 
} 
