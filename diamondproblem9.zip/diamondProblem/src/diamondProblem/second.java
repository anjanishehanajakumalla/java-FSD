package diamondProblem;

interface second {
    default void show() 
    { 
        System.out.println("Default Second"); 
    } 


}
