package keywords;

public class FinallyBlockDemo {
    public static void main(String[] args) {
        int a=10,b=0,r=0;
        try
        {
            r = a / b;
        }
        catch(ArithmeticException Ex)
        {
            System.out.print("Error : " + Ex.getMessage());
        }
        finally
        {
            System.out.print("\nThe result is : " + r);
        }
    }


}
