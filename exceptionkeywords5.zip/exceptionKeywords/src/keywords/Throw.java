package keywords;

public class Throw {
	public static void main(String[] args)
    {

        int a=20,b=0,r;

        try
        {
            if(b==0)        
                throw(new ArithmeticException("We Can't divide anything by zero."));
            else
            {
                r = a / b;
                System.out.print("\nThe result is : " + r);
            }
        }
        catch(ArithmeticException Ex)
        {
            System.out.print("\nError : " + Ex.getMessage());
        }

        System.out.print("\nEnd of program.");
    }
}

