package constr;

public class paramConstrDemo {
	public static void main(String[] args) {

		Std std1=new Std(7,"Navya");
		Std std2=new Std(5,"Sravani");
		std1.display();
		std2.display();
			}
	}

