package accessModifiers;

public class accessSpecifier2 {
	public static void main(String[] args) {
		//private
		System.out.println("Private Access Specifier");
		priaccessspecifier  obj = new priaccessspecifier(); 
	}
}

