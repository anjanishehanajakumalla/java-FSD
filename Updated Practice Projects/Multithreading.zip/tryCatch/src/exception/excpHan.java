package exception;

public class excpHan {
    public static void main(String args[]) {
        int[] array = new int[10];
        try 
        {
            array[13] = 5;
        }
        catch (ArrayIndexOutOfBoundsException e) 
        {
            System.out.println("Array index is more than its size"); 
        }
        finally 
        {
            System.out.println("The array size is " + array.length);
        }
    }

}
