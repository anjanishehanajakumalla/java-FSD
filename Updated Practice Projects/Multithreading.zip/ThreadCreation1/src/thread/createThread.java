package thread;


class Thr extends Thread	{
		public void run()
		{
			System.out.println("This is Multi Threading Program");
		}
	}

	public class createThread {

		public static void main(String[] args) {
			Thr th = new Thr();
			th.start();
			System.out.println("This is Main Method");
		}

	}


