package keywords;

public class ThrowsDemo {
    
	void Division() throws ArithmeticException
        {
            int a=17,b=0,r;
            r = a / b;
            System.out.print("The result is : " + r);
        }
         public static void main(String[] args)
        {
           ThrowsDemo T = new ThrowsDemo();
              try
             {
                 T.Division();
             }
             catch(ArithmeticException Ex)
             {
                 System.out.print("\nError : " + Ex.getMessage());
             }
             System.out.print("\nEnd of program.");
        }
    }



