package diamondProblem;

interface first {
	
	    default void show() 
	    { 
	        System.out.println("Default First"); 
	    } 

	

}
