/**
 * 
 */
/**
 * 
 */
module diamondProblem {
}