package bugFix;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FixBugs {

	    private String name;
	    private String location;
	    private String phoneNumber;
	    private String url;
	    private String imageUrl;
	    private List<String> reviews;
	    private double rating;
	    private String priceRange;

	    public FixBugs(String name, String location, String phoneNumber, String url, String imageUrl,
	                       List<String> reviews, double rating, String priceRange) {
	        this.name = name;
	        this.location = location;
	        this.phoneNumber = phoneNumber;
	        this.url = url;
	        this.imageUrl = imageUrl;
	        this.reviews = reviews;
	        this.rating = rating;
	        this.priceRange = priceRange;
	    }

	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public String getLocation() {
	        return location;
	    }

	    public void setLocation(String location) {
	        this.location = location;
	    }

	    public String getPhoneNumber() {
	        return phoneNumber;
	    }

	    public void setPhoneNumber(String phoneNumber) {
	        this.phoneNumber = phoneNumber;
	    }

	    public String getUrl() {
	        return url;
	    }

	    public void setUrl(String url) {
	        this.url = url;
	    }

	    public String getImageUrl() {
	        return imageUrl;
	    }

	    public void setImageUrl(String imageUrl) {
	        this.imageUrl = imageUrl;
	    }

	    public List<String> getReviews() {
	        return reviews;
	    }

	    public void setReviews(List<String> reviews) {
	        this.reviews = reviews;
	    }

	    public double getRating() {
	        return rating;
	    }

	    public void setRating(double rating) {
	        this.rating = rating;
	    }

	    public String getPriceRange() {
	        return priceRange;
	    }

	    public void setPriceRange(String priceRange) {
	        this.priceRange = priceRange;
	    }

	    public static void main(String[] args) {
	    	FixBugs restaurant = new FixBugs("FoodTree", "Canada, Street 21", "+1-23456", "www.FoodTree.com", "FoodTree.jpg",
	                new ArrayList<>(Arrays.asList("Excellent!", "Tasty!")), 4.0, "$");
	        System.out.println(restaurant.getName());
	        System.out.println(restaurant.getLocation());
	        System.out.println(restaurant.getPhoneNumber());
	        System.out.println(restaurant.getUrl());
	        System.out.println(restaurant.getImageUrl());
	        System.out.println(restaurant.getReviews());
	        System.out.println(restaurant.getRating());
	        System.out.println(restaurant.getPriceRange());
	    }
	}
