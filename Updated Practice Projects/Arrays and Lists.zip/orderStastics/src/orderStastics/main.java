package orderStastics;

public class main {
		public static void main(String[] args) {
			nthSmallest ob = new nthSmallest(); 
	        int arr[] = {24, 73, 32, 67, 34, 24, 56}; 
	        int n = arr.length;
	        int k = 3; 
	        System.out.println(k + "th smallest element is "+ ob.nthSmallest(arr, 0, n-1, k)); 
	    }
	}



